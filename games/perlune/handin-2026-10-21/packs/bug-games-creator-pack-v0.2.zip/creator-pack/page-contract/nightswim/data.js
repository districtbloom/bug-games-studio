// Night Swim · page data (kit v2), ported from the platform's earlier Night Swim page (src/data.js + the copy in src/markup.html). Invented items PROPOSED, see dnote.
const GAME = {
  key: 'nightswim', name: 'Night Swim', no: '052', slug: 'nightswim', mod: 'nightswim', maker: '@lowtide', size: '3.1 MB',
  kicker: '1.2 · The Second Lamp',
  lead: 'A whale made of stars swims past a lighthouse, collecting letters. The beam finds them first.',
  love: 93, revCount: '2,904', chips: ['Arcade', 'Quiet', 'Solo'], meta: '1 player · ~15 min',
  playing: '1,418', playingWord: 'swimming', hint: 'Hover to wake the whale', hintM: 'Tap to wake the whale',
  friends: 'kiko and 2 friends are in',
  echo: '#8FA3D8', rewardMs: 820, rewardSteps: 0,   // nothing moves faster than the whale
  ownWord: 'Found', boughtLine: 'Found for you: ',
  cont: { t: 'One letter short', s: 'Swim 4 · NIGH_ · the T is drifting in the beam', pct: 0.8, where: 'Swim 4' },
  pass: {
    name: 'Tide pass', unit: 'step', at: 13, left: '11 days left', price: 900,
    desc: 'One step for every swim. The free row is for everyone; the pass row is yours with the Tide pass.',
    rows: [
      ['tiles', '', 'Paper tiles'], ['eye', 'low', 'Low moon'], ['wake', 'p', 'Pearl wake'], ['pfff', 'q', '~? sticker'], ['tiles', 'w', 'Wave tiles'],
      ['wake', 'a', 'Amber wake'], ['sea', '', 'Open sea'], ['tiles', 'm', 'Mast tiles'], ['pfff', 'e', '… sticker'], ['wake', 'g', 'Gold wake'],
      ['tower', '', 'Night tower'], ['crumbs', '3', '300 crumbs'], ['wake', 'c', 'Dot wake'], ['pfff', '', 'Pfff sticker'], ['tower', 'b', 'Blue hour'],
      ['tiles', 'w', 'Wide tiles'], ['eye', 'half', 'Half moon'], ['crumbs', '4', '400 crumbs'], ['whale', 'p', 'Pearl whale'], ['eye', '', 'Full moon'],
      ['tower', 'g', 'Lamp tower'], ['sea', '', 'Dot sea'], ['wake', 'a', 'Amber trail'], ['crumbs', '5', '500 crumbs'], ['frame', '', 'Lamp frame'],
      ['eye', 'half', 'Waning moon'], ['whale', 'a', 'Amber whale'], ['tower', 'b', 'Blue tower'], ['frame', 'g', 'Gold frame'], ['whale', 's', 'Star whale']
    ],
    free: { 3: ['pfff', 'e', '… sticker'], 5: ['crumbs', '1', '50 crumbs'], 6: ['crumbs', '2', '100 crumbs'], 7: ['pfff', 'q', '~? sticker'], 9: ['pfff', '', 'Pfff sticker'], 10: ['crumbs', '1', '50 crumbs'], 12: ['crumbs', '3', '150 crumbs'], 14: ['pfff', 'q', '~? sticker'], 15: ['crumbs', '1', '50 crumbs'], 18: ['crumbs', '3', '150 crumbs'], 20: ['crumbs', '1', '50 crumbs'], 21: ['pfff', '', 'Pfff sticker'], 24: ['crumbs', '4', '200 crumbs'], 25: ['crumbs', '1', '50 crumbs'], 27: ['pfff', '', 'Pfff sticker'], 28: ['pfff', 'q', '~? sticker'], 30: ['crumbs', '5', '250 crumbs'] },
    bug: { 8: ['tower', 'g', 'Gold tower'], 16: ['frame', 'g', 'Lamp frame'], 30: ['wake', 'g', 'Gold wake'] }
  },
  ev: { name: 'Longest Night', text: 'The nights are long this week. Every letter anyone swallows lights a dot in the sea. Find 20,000 together.', count: '11,420', unit: 'so far', ends: 'Ends in 02d 11h', when: 'Live this week' },
  media: [
    { label: 'Key art, live', draw: 'poster', cap: 'Key art · the For You poster, alive' },
    { label: 'In the game: the swim', draw: 'gmedia|swim', cap: 'In the game · the whale, the beam, the letters' },
    { label: 'New in 1.2: the second lamp', draw: 'gmedia|lamp', cap: 'New in 1.2 · two towers, one whale between them' }
  ],
  store: [
    { id: 'pass', name: 'Tide pass', kind: '30 steps · one per swim', crumbs: 900, pass: true },
    { id: 'pearl', name: 'Pearl whale', kind: 'Skin · the dots go pale', crumbs: 450 },
    { id: 'amber', name: 'Amber whale', kind: 'Skin · the dots go warm', crumbs: 600, isNew: true },
    { id: 'moon', name: 'Full Moon eye', kind: 'Eye · wide open', crumbs: 300 },
    { id: 'blue', name: 'Blue Hour tower', kind: 'Tower · bands go cobalt', crumbs: 350 },
    { id: 'wake', name: 'Dot Wake', kind: 'Trail · a line of dots', crumbs: 250 },
    { id: 'tiles', name: 'Paper Tiles', kind: 'Letters · cream, not glass', crumbs: 150 }
  ],
  storeSub: 'Skins for the sea',
  owned0: ['pass', 'tiles'],
  updates: [
    { id: 'lamp', date: '12 Oct', v: '1.2', title: 'The Second Lamp', from: '2 of 3 changes from players', draw: 'update|lamp' },
    { id: 'wake', date: '28 Sep', v: '1.1', title: 'Dot Wake', from: '1 of 1 change from players', draw: 'update|wake' },
    { id: 'first', date: '14 Sep', v: '1.0', title: 'One whale, one beam', from: 'Launch: one sea, one lighthouse', draw: 'update|first' }
  ],
  reviews: [
    { q: 'I kept missing the T. The whale sighed. So did I.', v: 'LOVED', h: '@tidepool', hrs: '6H' },
    { q: 'Nothing happens, slowly, and I did not look at my phone once.', v: 'LOVED', h: '@moth_light', hrs: '3H' },
    { q: 'Too quiet for me. The beam is lovely and I fell asleep, which I think is the point.', v: 'NOT FOR ME', h: '@loudkid', hrs: '1H' }
  ],
  aboutP: 'A whale made of stars swims slowly past a lighthouse. Letters drift in from the right and the beam finds them first. Swallow them in order, spell the words of the night, and keep out of the way when a neighbour gets crowded.',
  goal: 'Spell NIGHT in one swim. Then swim on.',
  details: [['Genre', 'Quiet arcade swim'], ['Players', '1'], ['Input', 'Keys, pad, touch'], ['Updated', '12 Oct 2026'], ['Released', '14 Sep 2026'], ['Store', 'Cosmetics + Tide pass']],
  controls: [
    { id: 'kbd', binds: [{ caps: ['↑', '↓'], act: 'Swim', note: 'Up and down. The whale is slow' }, { caps: ['Space'], act: 'Swallow', note: 'Open wide when a letter is in the beam' }, { caps: ['S'], act: 'Dive', note: 'Slip under the beam to rest' }, { caps: ['Shift'], act: 'Curl', note: 'When a neighbour crowds you' }] },
    { id: 'pad', binds: [{ caps: ['L stick'], act: 'Swim', note: 'Left stick' }, { caps: ['A'], act: 'Swallow', note: 'Open wide in the beam' }, { caps: ['B'], act: 'Dive', note: 'Under the beam' }, { caps: ['RT'], act: 'Curl', note: 'When crowded' }] },
    { id: 'touch', binds: [{ caps: ['Drag'], act: 'Swim', note: 'Anywhere' }, { caps: ['Tap'], act: 'Swallow', note: 'In the beam' }, { caps: ['Swipe'], act: 'Dive', note: 'Swipe down' }, { caps: ['Hold'], act: 'Curl', note: 'When crowded' }] }
  ],
  tips: ['Letters drift in from the right. The beam finds them first.', 'Spell NIGHT in order for the spout.', 'Curled up? Wait a breath. The whale comes back.'],
  inLabel: { kbd: 'Keys', pad: 'Gamepad', touch: 'Touch' },
  achs: [
    { g: 'first', name: 'First Letter', rule: 'Swallow a letter in the beam.', rare: 82, st: 'earned', date: 'Oct 02' },
    { g: 'spout', name: 'Spout', rule: 'Finish a word. The whale lets out a spout.', rare: 54, st: 'earned', date: 'Oct 03' },
    { g: 'curl', name: 'Breach', rule: 'Curl up when a neighbour crowds you, then swim on.', rare: 33, st: 'earned', date: 'Oct 07' },
    { g: 'night', name: 'NIGHT', rule: 'Spell N, I, G, H, T in one swim.', rare: 21, st: 'earned', date: 'Oct 11' },
    { g: 'found', name: 'Found', rule: 'Be found by the beam 20 times.', rare: 38, st: 'prog', n: 7, of: 20 },
    { g: 'lamp', name: 'Lamp Lit', rule: 'Keep the beam on you for 60 seconds in one swim.', rare: 12, st: 'prog', n: 38, of: 60 },
    { g: 'shoot', name: 'Wish', rule: 'Catch five shooting stars.', rare: 17, st: 'prog', n: 3, of: 5 },
    { g: 'long', name: 'Longest Night', rule: 'Find a letter during Longest Night. Event only.', rare: 4, st: 'locked', note: 'During Longest Night' }
  ],
  kindColors: ['#C4B5FF', '#C6D4FF', '#7FE3C0'],
  next: { v: '1.3', n: 'Fog banks', when: '~Nov 10', from: '1,014' },
  lastPct: 67,
  requests: [
    { id: 'fog', kind: 'WISH', title: 'Fog banks: the beam gets lost in them', base: 1640, step: 2, reply: 'It is coming. Slow, grey, and the lamp still works.' },
    { id: 'pod', kind: 'WISH', title: 'A second whale, far off, that follows yours', base: 1104, step: 1 },
    { id: 'tide', kind: 'IDEA', title: 'Letters that stay lit for the next swim', base: 702, step: 0, mine: true }
  ],
  crew: [{ h: 'lowtide', i: 'L', role: 'Code & design' }, { h: 'moth_light', i: 'M', role: 'Dots & light' }, { h: 'slowtide', i: 'S', role: 'Sound' }],
  followers: 12804, built: '67% built from player requests',
  more: [
    { key: 'threadbare', name: 'Threadbare', no: '002', love: 94, len: '~12 min' },
    { key: 'tinyworlds', name: 'Five Tiny Worlds', no: '031', love: 90, len: '~20 min' },
    { key: 'miradouro', name: 'Miradouro', no: '021', love: 94, len: '~12 min' },
    { key: 'typos', name: 'Typos', no: '047', love: 93, len: '~10 min' }
  ],
  moreSub: 'Quiet nights · slow games',
  ticker: [{ b: '1,418', c: ' swimming now' }, { dot: true, l: 'Longest Night', href: '#live', c: ' live · 11,420 of 20,000 letters found' }, { a: 'Tide pass · ', b: '11', c: ' days left' }, { a: 'next: ', l: '1.3 Fog banks', href: '#made-by', c: ' · ~Nov 10' }, { b: '2,031', c: ' games made this week' }],
  dnote: 'Design note · PROPOSED (not in the world yet): Longest Night event · Tide pass and its 30 rewards · store items and prices · updates 1.1 Dot Wake, 1.2 The Second Lamp, 1.3 Fog banks · the 8 seals · controls · Shape it requests · reviews, numbers, crew handles. Derived: the whale, the lighthouse, letters and tiles, the dot sea, the gold eye, poster and loop (its living-poster module), its art bible. Ported to kit v2 by the platform.'
};
