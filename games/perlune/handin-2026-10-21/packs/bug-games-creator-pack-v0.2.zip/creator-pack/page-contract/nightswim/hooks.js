// Night Swim · asset hooks (kit v2), ported by the platform. Runs in the game's own scope after vendor/harvest.js
// (storeArt, reward, seal + KIND, eventArt, contArt, shareArt, nsIcon, nsEmblem, beat, gmedia, setBg, star, dot, K, M, TAU).
// the standard hooks come straight from the old page's own dispatcher (its pass rows used '-' for an empty ground)
KIT.delegate(drawNamed, { empty: '-', update: 'beat', extra: ['gmedia'] });

// the reward verb: it is found. A slanted band of beam crosses the tile, gold pellets run along its top, then it holds with a gold frame and one sparkle.
ART.draw.reward = (c, w, h, id, p) => {
  p = +p; if (p <= 0) return;
  if (p < 1) {   // the band of beam sweeps left to right (gone by the held frame)
    const x = -w * 0.4 + w * 1.8 * Math.min(1, p / 0.7), bw = w * 0.34;
    c.fillStyle = 'rgba(255,214,140,0.28)'; c.beginPath(); c.moveTo(x, 0); c.lineTo(x + bw, 0); c.lineTo(x + bw - w * 0.3, h); c.lineTo(x - w * 0.3, h); c.closePath(); c.fill();
  }
  const n = 14, run = Math.min(n, Math.floor(p / 0.7 * n));   // the pellet run
  c.fillStyle = K.gold; c.beginPath(); for (let i = 0; i < run; i++) dot(c, 8 + i * (w - 16) / (n - 1), 6, Math.max(1.4, w * 0.011)); c.fill();
  if (p > 0.7) {
    const k = Math.min(1, (p - 0.7) / 0.3), lw = Math.max(2, w * 0.016);
    c.strokeStyle = K.gold; c.lineWidth = lw; c.beginPath();
    const L = (w + h) * 2 * k; let left = L;   // the frame draws itself clockwise from the top left
    const seg = [[lw, lw, w - lw, lw], [w - lw, lw, w - lw, h - lw], [w - lw, h - lw, lw, h - lw], [lw, h - lw, lw, lw]];
    c.moveTo(lw, lw);
    for (const [x0, y0, x1, y1] of seg) { const len = Math.hypot(x1 - x0, y1 - y0); if (left <= 0) break; const t = Math.min(1, left / len); c.lineTo(x0 + (x1 - x0) * t, y0 + (y1 - y0) * t); left -= len; }
    c.stroke();
    if (p >= 1) { star(c, w * 0.12, h * 0.12, Math.max(5, w * 0.06), K.gold); star(c, w * 0.88, h * 0.86, Math.max(3, w * 0.035), '#fff'); }
  }
};

// the hero backdrop: the page's night (stars, loose dim letters) ending on the dot sea, the tower and its beam skimming the water
ART.draw.backdrop = (c, w, h, mobile) => setBg(c, w, h, { frames: [], floor: { y: h - (mobile === 'true' ? 110 : 150) }, mobile: mobile === 'true' });
