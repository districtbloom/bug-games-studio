BUG_MODS.nightswim = {
  key: 'nightswim',
  no: '052',
  title: 'Night Swim',
  maker: '@lowtide',
  kind: 'Sky-swim collector',
  verb: 'Swallow.',
  ground: '#03040B',
  ink: '#FFD45C',
  rants: ['…', 'pfff', '~?'],
  hits: ['✶', 'oof'],
  items: {
    letter(ctx, x, y, t, a) {
      t = t || 0;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.sin(t * 7) * 0.35);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(255,212,92,0.22)';
      ctx.beginPath(); ctx.arc(0, 0, 15, 0, 6.2832); ctx.fill();
      ctx.fillStyle = '#05060E';
      ctx.fillRect(-10, -10, 20, 20);
      ctx.strokeStyle = '#FFD45C'; ctx.lineWidth = 1.2; ctx.strokeRect(-10, -10, 20, 20);
      ctx.font = '20px "Instrument Serif", Georgia, serif';
      ctx.fillStyle = '#FFF4D8'; ctx.fillText('Q', 0, 1.5);
      ctx.restore();
    },
    star(ctx, x, y, t, a) {
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(a || 0);
      const sp = (r) => { ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(0, 0, r, 0); ctx.quadraticCurveTo(0, 0, 0, r); ctx.quadraticCurveTo(0, 0, -r, 0); ctx.quadraticCurveTo(0, 0, 0, -r); };
      ctx.fillStyle = 'rgba(255,212,92,0.25)'; ctx.beginPath(); ctx.arc(0, 0, 12, 0, 6.2832); ctx.fill();
      ctx.fillStyle = '#FFF4D8'; sp(14); ctx.fill();
      ctx.fillStyle = '#FFD45C';
      ctx.beginPath(); ctx.arc(0, 0, 2.6, 0, 6.2832); ctx.fill();
      ctx.restore();
    }
  },
  create(api) {
    const R = api.rnd, TAU = Math.PI * 2;
    // Study B · STAGE: black stage, the lighthouse beam is the only light; the particle whale is dim until the beam finds it.
    const BG = '#03040B', DIM = '#2C3B6C', DIM2 = '#6E86C8', LIT = '#FFF1D2', GOLD = '#FFD45C', HAZE = '#0A0E22';
    const COLS = ['#FFF1D2', GOLD, '#FFFFFF', '#C6D4FF', GOLD, '#FFFFFF'];
    const TH = 1.05;
    const ABC = 'NIGHTSWMAORLEUVBY';
    const WORD = 'NIGHT';
    const cl = (v, a, b) => (v < a ? a : v > b ? b : v);
    const lerp = (a, b, k) => a + (b - a) * k;
    const ease = (k) => (k <= 0 ? 0 : k >= 1 ? 1 : k * k * (3 - 2 * k));
    const hash = (n) => { const s = Math.sin(n * 127.1) * 43758.5453; return s - Math.floor(s); };
    const SERIF = '"Instrument Serif", Georgia, serif';

    // ---------- the sky ----------
    const stars = [];
    for (let i = 0; i < 75; i++) stars.push({ x: hash(i + 3.1), y: hash(i + 9.7) * 0.82, r: hash(i + 1.3) < 0.05 ? 1.4 : 0.35 + hash(i + 2.3) * 0.6, ph: hash(i) * TAU, sp: 0.8 + hash(i + 5) * 2.6, d: 0.15 + hash(i + 7) * 0.85 });
    // stars carried inside the whale (whale-local coords: u along body, d across)
    const inner = [];
    for (let i = 0; i < 48; i++) inner.push({ u: 0.1 + R() * 0.8, d: (R() * 2 - 1) * 0.75, r: 0.5 + R(), ph: R() * TAU });
    const JOINTS = [{ u: 0.1, d: -0.05 }, { u: 0.27, d: 0.25 }, { u: 0.43, d: -0.45 }, { u: 0.57, d: 0.25 }, { u: 0.7, d: -0.5 }, { u: 0.86, d: 0.3 }, { u: 0.64, d: 0.95 }];
    const EDGES = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [3, 6], [2, 4]];

    function newLet(x) {
      return { ch: ABC[(R() * ABC.length) | 0], x: x, y: 0.1 + R() * 0.62, c: COLS[(R() * 6) | 0], ph: R() * TAU, st: 0, sz: 1 };
    }
    const lets = [];
    for (let i = 0; i < 8; i++) lets.push(newLet(0.05 + i * 0.13 + R() * 0.05));

    // ---------- state ----------
    const S = {
      clock: 0, scroll: 0, spd: 0.03, ph: 0, parts: [], pellets: [], gag: null, gagN: 0, hit: null, look: null,
      scatter: 0, prevMode: '', d0: 0, nextBreath: 5.5, nextShoot: 3, shoot: null, prevLt: 0, popAt: 0,
      pose: null, vel: {}, anc: { x: 0.6, y: 0.4 }, eyeX: 0, eyeY: 0, mouth: [0, 0], fwd: [1, 0], blow: [0, 0], beams: []
    };
    // fine film grain, drawn once
    let GRAIN = null;
    function grain(ctx) {
      if (GRAIN === null) {
        GRAIN = false;
        try {
          if (typeof OffscreenCanvas !== 'undefined') {
            const g = new OffscreenCanvas(128, 128), c = g.getContext('2d');
            for (let i = 0; i < 2600; i++) { c.fillStyle = hash(i * 1.7) < 0.5 ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.7)'; c.fillRect((hash(i + 0.31) * 128) | 0, (hash(i + 0.77) * 128) | 0, 1, 1); }
            GRAIN = g;
          }
        } catch (e) { GRAIN = false; }
      }
      if (!GRAIN) return null;
      if (S.patCtx !== ctx) { S.patCtx = ctx; S.pat = ctx.createPattern(GRAIN, 'repeat'); }
      return S.pat;
    }

    // ---------- whale rig ----------
    const N = 56;
    const TT = [[0, 0.012], [0.1, 0.024], [0.25, 0.05], [0.45, 0.078], [0.62, 0.086], [0.78, 0.078], [0.88, 0.062], [0.95, 0.04], [1, 0.004]];
    const TB = [[0, 0.012], [0.1, 0.028], [0.25, 0.064], [0.45, 0.1], [0.62, 0.118], [0.78, 0.112], [0.88, 0.09], [0.95, 0.06], [1, 0.012]];
    const tab = (T, u) => {
      for (let i = 1; i < T.length; i++) if (u <= T[i][0]) { const a = T[i - 1], b = T[i], k = (u - a[0]) / (b[0] - a[0]); return a[1] + (b[1] - a[1]) * (k * k * (3 - 2 * k)); }
      return T[T.length - 1][1];
    };
    const thT = new Float32Array(N + 1), thB = new Float32Array(N + 1);
    for (let i = 0; i <= N; i++) { thT[i] = tab(TT, i / N); thB[i] = tab(TB, i / N); }
    const G = { px: new Float32Array(N + 1), py: new Float32Array(N + 1), ca: new Float32Array(N + 1), sa: new Float32Array(N + 1),
      tx: new Float32Array(N + 1), ty: new Float32Array(N + 1), bx: new Float32Array(N + 1), by: new Float32Array(N + 1), L: 100 };

    function build(cx, cy, L, ang, bend, wave, ph, th, jaw) {
      let x = 0, y = 0;
      for (let i = 0; i <= N; i++) {
        const u = i / N;
        const a = ang + bend * (u - 0.55) + wave * Math.sin(u * 4.6 - ph) * (1 - u) * (1 - u) * 1.6;
        G.px[i] = x; G.py[i] = y; G.ca[i] = Math.cos(a); G.sa[i] = Math.sin(a);
        x += G.ca[i] * L / N; y += G.sa[i] * L / N;
      }
      const ox = cx - G.px[31], oy = cy - G.py[31];
      for (let i = 0; i <= N; i++) {
        const u = i / N, px = G.px[i] + ox, py = G.py[i] + oy, nx = -G.sa[i], ny = G.ca[i];
        const jo = u > 0.78 ? jaw * L * 0.6 * (u - 0.78) : 0;
        G.px[i] = px; G.py[i] = py;
        G.tx[i] = px - nx * thT[i] * L * th; G.ty[i] = py - ny * thT[i] * L * th;
        G.bx[i] = px + nx * (thB[i] * L * th + jo); G.by[i] = py + ny * (thB[i] * L * th + jo);
      }
      G.L = L;
    }
    function at(u, d) {
      const f = cl(u, 0, 1) * N, i = Math.min(N - 1, f | 0), k = f - i, m = (d + 1) / 2;
      const tx = lerp(G.tx[i], G.tx[i + 1], k), ty = lerp(G.ty[i], G.ty[i + 1], k);
      const bx = lerp(G.bx[i], G.bx[i + 1], k), by = lerp(G.by[i], G.by[i + 1], k);
      return [lerp(tx, bx, m), lerp(ty, by, m)];
    }
    const qb = (a, c, b, s) => { const r = 1 - s; return [r * r * a[0] + 2 * r * s * c[0] + s * s * b[0], r * r * a[1] + 2 * r * s * c[1] + s * s * b[1]]; };

    function sparkle(ctx, x, y, r) {
      ctx.moveTo(x, y - r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.quadraticCurveTo(x, y, x, y + r);
      ctx.quadraticCurveTo(x, y, x - r, y);
      ctx.quadraticCurveTo(x, y, x, y - r);
    }
    function wedge(ctx, b) {
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x + Math.cos(b.a - b.sp) * b.len, b.y + Math.sin(b.a - b.sp) * b.len);
      ctx.lineTo(b.x + Math.cos(b.a + b.sp) * b.len, b.y + Math.sin(b.a + b.sp) * b.len);
      ctx.closePath();
    }
    // the whole silhouette (body + fin + flukes) as one path
    function shapePath(ctx, fin, fl) {
      ctx.moveTo(G.tx[0], G.ty[0]);
      for (let i = 1; i <= N; i++) ctx.lineTo(G.tx[i], G.ty[i]);
      for (let i = N; i >= 0; i--) ctx.lineTo(G.bx[i], G.by[i]);
      ctx.closePath();
      ctx.moveTo(fin.B1[0], fin.B1[1]);
      ctx.quadraticCurveTo(fin.C1[0], fin.C1[1], fin.T[0], fin.T[1]);
      ctx.quadraticCurveTo(fin.C2[0], fin.C2[1], fin.B2[0], fin.B2[1]);
      ctx.closePath();
      for (const lobe of fl) {
        ctx.moveTo(lobe[0][0], lobe[0][1]);
        ctx.quadraticCurveTo(lobe[1][0], lobe[1][1], lobe[2][0], lobe[2][1]);
        ctx.quadraticCurveTo(lobe[3][0], lobe[3][1], lobe[4][0], lobe[4][1]);
        ctx.closePath();
      }
    }
    function dotsPath(ctx, pts, r) { if (r < 1.1) { const d = r * 1.8; for (let j = 0; j < pts.length; j += 2) ctx.rect(pts[j] - d / 2, pts[j + 1] - d / 2, d, d); return; } for (let j = 0; j < pts.length; j += 2) { ctx.moveTo(pts[j] + r, pts[j + 1]); ctx.arc(pts[j], pts[j + 1], r, 0, TAU); } }

    function drawWhale(ctx, t, o) {
      const L = G.L, sc = S.scatter * L * 0.09;
      const jit = (j) => (sc > 0.01 ? [(hash(j) - 0.5) * sc, (hash(j + 91.7) - 0.5) * sc] : [0, 0]);
      const fin = finGeom(o.fin), fl = flukeGeom(o.flap);
      const hinge = at(0.79, 0.12), nT = [G.tx[N], G.ty[N]], nB = [G.bx[N], G.by[N]];
      const jp = JOINTS.map((q) => at(q.u, q.d));
      jp.push(fin.T);
      // ---- particle whale: dim everywhere, lit where the beam falls ----
      ctx.beginPath(); shapePath(ctx, fin, fl);
      ctx.fillStyle = 'rgba(4,6,16,0.92)'; ctx.fill();
      if (o.jaw > 0.04) {
        ctx.beginPath(); ctx.moveTo(hinge[0], hinge[1]); ctx.lineTo(nT[0], nT[1]); ctx.lineTo(nB[0], nB[1]); ctx.closePath();
        ctx.fillStyle = '#1A0E10'; ctx.fill();
        ctx.strokeStyle = 'rgba(255,212,92,0.75)'; ctx.lineWidth = Math.max(0.8, L * 0.003);
        ctx.beginPath();
        for (let k = 1; k < 7; k++) { const s = k / 7, a = [lerp(hinge[0], nT[0], s), lerp(hinge[1], nT[1], s)], b = [lerp(hinge[0], nB[0], s), lerp(hinge[1], nB[1], s)]; ctx.moveTo(a[0], a[1]); ctx.lineTo(lerp(a[0], b[0], 0.45), lerp(a[1], b[1], 0.45)); }
        ctx.stroke();
      }
      const r0 = Math.max(0.55, L * 0.0036);
      const rim = [], fill = [];
      const M = cl(Math.round(L / 2.6), 40, 200);
      let jx = 0;
      for (let k = 0; k <= M; k++) {
        const f = (k / M) * N, i = Math.min(N - 1, f | 0), q = f - i, jj = jit(jx++);
        rim.push(lerp(G.tx[i], G.tx[i + 1], q) + jj[0], lerp(G.ty[i], G.ty[i + 1], q) + jj[1]);
        rim.push(lerp(G.bx[i], G.bx[i + 1], q) + jj[0], lerp(G.by[i], G.by[i + 1], q) + jj[1]);
      }
      const lipN = Math.max(6, (M * 0.2) | 0);
      for (let k = 1; k < lipN; k++) {
        const s = k / lipN;
        rim.push(lerp(hinge[0], nT[0], s), lerp(hinge[1], nT[1], s));
        if (o.jaw > 0.04) rim.push(lerp(hinge[0], nB[0], s), lerp(hinge[1], nB[1], s));
      }
      const fN = Math.max(10, (M * 0.32) | 0);
      for (let k = 0; k <= fN; k++) { const s = k / fN, a = qb(fin.B1, fin.C1, fin.T, s), b = qb(fin.T, fin.C2, fin.B2, s); rim.push(a[0], a[1], b[0], b[1]); }
      const lN = Math.max(6, (M * 0.15) | 0);
      for (const lobe of fl) for (let k = 0; k <= lN; k++) { const s = k / lN, a = qb(lobe[0], lobe[1], lobe[2], s), b = qb(lobe[2], lobe[3], lobe[4], s); rim.push(a[0], a[1], b[0], b[1]); }
      // hatch rows along the body (ventral grooves + dorsal rows), like a point cloud
      const gs = Math.max(16, Math.min(60, L / 6));
      for (const dd of [-0.55, -0.12, 0.3, 0.48, 0.64, 0.8]) {
        for (let k = 0; k <= gs; k++) {
          const u = dd > 0.25 ? 0.5 + 0.46 * (k / gs) : 0.12 + 0.8 * (k / gs), dv = dd > 0.25 ? dd + (1 - dd) * Math.pow(k / gs, 3) * 0.6 : dd, p = at(u, dv), jj = jit(k * 7 + dd * 100);
          fill.push(p[0] + jj[0], p[1] + jj[1]);
        }
      }
      for (let j = 0; j < inner.length; j++) { const q = inner[j], p = at(q.u, q.d); fill.push(p[0], p[1]); }
      ctx.fillStyle = DIM; ctx.beginPath(); dotsPath(ctx, fill, r0 * 0.75); ctx.fill();
      ctx.fillStyle = DIM2; ctx.beginPath(); dotsPath(ctx, rim, r0); ctx.fill();
      // the light
      const lit = S.beams.filter((b) => b.al > 0.05 && b.len > 4);
      if (lit.length) {
        ctx.save();
        ctx.beginPath(); for (const b of lit) wedge(ctx, b); ctx.clip();
        ctx.beginPath(); shapePath(ctx, fin, fl);
        ctx.fillStyle = 'rgba(255,214,140,0.10)'; ctx.fill();
        ctx.fillStyle = '#E9D8B0'; ctx.beginPath(); dotsPath(ctx, fill, r0 * 0.95); ctx.fill();
        ctx.fillStyle = LIT; ctx.beginPath(); dotsPath(ctx, rim, r0 * 1.35); ctx.fill();
        ctx.strokeStyle = 'rgba(255,241,210,0.55)'; ctx.lineWidth = Math.max(0.7, L * 0.0026);
        ctx.beginPath();
        for (const e of EDGES) { const a = jp[e[0]], b = jp[e[1]]; ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); }
        ctx.moveTo(jp[6][0], jp[6][1]); ctx.lineTo(jp[7][0], jp[7][1]);
        ctx.stroke();
        ctx.restore();
      }
      for (const p of S.pellets) {
        ctx.fillStyle = GOLD;
        ctx.beginPath();
        for (let k = 0; k < 6; k++) { const q = at(p.u + k * 0.018, 0.05), rr = L * 0.01 * (1 - k / 7); ctx.moveTo(q[0] + rr, q[1]); ctx.arc(q[0], q[1], rr, 0, TAU); }
        ctx.fill();
      }
      for (let j = 0; j < jp.length; j++) {
        const q = JOINTS[j] || { u: 0.64 }, p = jp[j], jj = jit(j + 900);
        let rr = Math.max(1.8, L * 0.012) * (1 + 0.25 * Math.sin(t * 3 + j * 1.3)), c = '#8FA3D8';
        for (const pl of S.pellets) if (Math.abs(pl.u - q.u) < 0.07) { rr *= 1.9; c = GOLD; }
        ctx.fillStyle = c;
        ctx.beginPath(); sparkle(ctx, p[0] + jj[0], p[1] + jj[1], rr); ctx.fill();
      }
      // blowhole, eye, mouth
      const bh = at(0.745, -1);
      S.blow = bh;
      const E = at(0.85, -0.28);
      S.eyeX = E[0]; S.eyeY = E[1];
      moon(ctx, E[0], E[1], Math.max(2.6, L * 0.031) * (o.eyeSz || 1), o.eye, o.lx, o.ly, o.brow);
      S.mouth = [lerp(nT[0], nB[0], 0.5), lerp(nT[1], nB[1], 0.5)];
      S.fwd = [G.ca[N], G.sa[N]];
    }

    function finGeom(beta) {
      const L = G.L, i = Math.round(0.65 * N), ca = G.ca[i], sa = G.sa[i];
      const B1 = at(0.7, 0.9), B2 = at(0.6, 0.85);
      const Dx = -ca * Math.cos(beta) - sa * Math.sin(beta), Dy = -sa * Math.cos(beta) + ca * Math.sin(beta);
      let px = -Dy, py = Dx;
      if (px * ca + py * sa < 0) { px = -px; py = -py; }
      const len = 0.29 * L, mx = (B1[0] + B2[0]) / 2, my = (B1[1] + B2[1]) / 2;
      const T = [mx + Dx * len, my + Dy * len];
      return { B1, B2, T,
        C1: [B1[0] + Dx * len * 0.5 + px * L * 0.055, B1[1] + Dy * len * 0.5 + py * L * 0.055],
        C2: [B2[0] + Dx * len * 0.55 - px * L * 0.012, B2[1] + Dy * len * 0.55 - py * L * 0.012] };
    }
    function flukeGeom(flap) {
      const L = G.L, P = [G.px[0], G.py[0]], c = Math.cos(flap), s = Math.sin(flap);
      const bx0 = -G.ca[0], by0 = -G.sa[0];
      const bx = bx0 * c - by0 * s, by = bx0 * s + by0 * c, nx = -by, ny = bx;
      const pt = (b, n) => [P[0] + bx * b * L + nx * n * L, P[1] + by * b * L + ny * n * L];
      const out = [];
      for (const sg of [-1, 1]) out.push([pt(0, 0), pt(0.015, sg * 0.09), pt(0.1, sg * 0.175), pt(0.105, sg * 0.05), pt(0.065, 0)]);
      return out;
    }

    function moon(ctx, x, y, r, open, lx, ly, brow) {
      const MOON = GOLD, LID = '#05070F', PUP = '#1A0F10';
      ctx.fillStyle = 'rgba(255,212,92,0.16)'; ctx.beginPath(); ctx.arc(x, y, r * 1.9, 0, TAU); ctx.fill();
      ctx.save();
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU);
      ctx.fillStyle = MOON; ctx.fill();
      ctx.clip();
      if (open < 1.05) {
        const off = r * (0.32 + cl(open, 0, 1.05) * 1.75);
        ctx.beginPath(); ctx.arc(x - off * 0.55, y - off * 0.84, r * 1.02, 0, TAU);
        ctx.fillStyle = LID; ctx.fill();
      }
      if (open > 0.55) {
        ctx.fillStyle = PUP;
        ctx.beginPath(); ctx.arc(x + (lx || 0) * r * 0.42, y + (ly || 0) * r * 0.42, r * 0.36, 0, TAU); ctx.fill();
        ctx.fillStyle = '#FFFFFF';
        ctx.beginPath(); ctx.arc(x + (lx || 0) * r * 0.42 - r * 0.12, y + (ly || 0) * r * 0.42 - r * 0.12, r * 0.1, 0, TAU); ctx.fill();
      }
      ctx.restore();
      if (brow > 0.02) {
        ctx.strokeStyle = MOON; ctx.lineCap = 'round'; ctx.lineWidth = Math.max(1.5, r * 0.4);
        ctx.beginPath();
        ctx.moveTo(x - r * 1.3, y - r * (1.25 + 0.4 * brow));
        ctx.lineTo(x + r * 1.25, y - r * (1.35 - 0.5 * brow));
        ctx.stroke();
      }
    }

    // ---------- props ----------
    function lighthouse(ctx, x, base, H, t, lean, lamp) {
      ctx.save();
      ctx.translate(x, base);
      ctx.rotate(lean);
      const bw = H * 0.2, tw = H * 0.13, th = H * 0.7, y0 = -H * 0.05, gy = y0 - th, ly = gy - H * 0.035, lh = H * 0.12, lw = tw * 0.9;
      const tower = () => { ctx.beginPath(); ctx.moveTo(-bw / 2, y0); ctx.lineTo(-tw / 2, gy); ctx.lineTo(tw / 2, gy); ctx.lineTo(bw / 2, y0); ctx.closePath(); };
      const rock = () => { ctx.beginPath(); ctx.moveTo(-bw * 1.5, 4); ctx.quadraticCurveTo(-bw * 1.2, -H * 0.08, -bw * 0.4, -H * 0.06); ctx.quadraticCurveTo(bw * 0.6, -H * 0.1, bw * 1.4, 4); ctx.closePath(); };
      const roof = () => { ctx.beginPath(); ctx.moveTo(-lw * 0.75, ly - lh); ctx.lineTo(0, ly - lh - H * 0.1); ctx.lineTo(lw * 0.75, ly - lh); ctx.closePath(); };
      ctx.fillStyle = '#05060E'; rock(); ctx.fill();
      ctx.fillStyle = '#1C2440';
      for (let k = 0; k < 7; k++) { const a = qb([-bw * 1.5, 4], [-bw * 0.4, -H * 0.12], [bw * 1.4, 4], k / 6); ctx.fillRect(a[0] - 0.6, a[1] - 0.6, 1.2, 1.2); }
      tower(); ctx.fillStyle = '#080A16'; ctx.fill();
      ctx.save(); tower(); ctx.clip();
      for (let k = 0; k < 5; k += 2) { ctx.fillStyle = '#2A0E16'; ctx.fillRect(-bw, y0 - th * (k + 1) / 5, bw * 2, th / 5 + 0.5); }
      ctx.fillStyle = 'rgba(255,212,92,' + (0.12 + 0.25 * lamp).toFixed(3) + ')'; ctx.fillRect(-bw, gy, bw * 0.55, th);
      ctx.restore();
      ctx.strokeStyle = '#26335E'; ctx.lineWidth = Math.max(0.6, H * 0.01); tower(); ctx.stroke();
      ctx.fillStyle = '#080A16'; ctx.fillRect(-tw * 0.85, gy - H * 0.035, tw * 1.7, H * 0.035);
      ctx.fillStyle = GOLD; ctx.fillRect(-lw / 2, ly - lh, lw, lh);
      ctx.fillStyle = '#FFFFFF'; ctx.beginPath(); ctx.arc(0, ly - lh / 2, lw * 0.3 * (1 + lamp * 0.6), 0, TAU); ctx.fill();
      ctx.fillStyle = '#080A16'; roof(); ctx.fill();
      ctx.restore();
      const ry = -H * 0.05 - th - H * 0.035 - H * 0.06;
      return [x - Math.sin(lean) * ry, base + Math.cos(lean) * ry];
    }

    function drawBeams(ctx, flash) {
      ctx.save();
      ctx.globalCompositeOperation = 'lighter';
      for (const b of S.beams) {
        if (b.al < 0.02 || b.len < 2) continue;
        const ex = b.x + Math.cos(b.a) * b.len, ey = b.y + Math.sin(b.a) * b.len;
        const g = ctx.createLinearGradient(b.x, b.y, ex, ey);
        g.addColorStop(0, 'rgba(255,224,150,' + (0.42 * b.al).toFixed(3) + ')');
        g.addColorStop(0.55, 'rgba(255,200,120,' + (0.16 * b.al).toFixed(3) + ')');
        g.addColorStop(1, 'rgba(255,180,120,0)');
        ctx.fillStyle = g;
        ctx.beginPath(); wedge(ctx, b); ctx.fill();
        ctx.beginPath(); wedge(ctx, { x: b.x, y: b.y, a: b.a, sp: b.sp * 0.35, len: b.len * 0.85 }); ctx.fill();
      }
      ctx.restore();
    }
    function litAt(X, Y) {
      let lit = 0;
      for (const b of S.beams) {
        if (b.al < 0.05) continue;
        const ax = X - b.x, ay = Y - b.y, la = Math.atan2(ay, ax), dd = Math.hypot(ax, ay);
        const df = Math.abs(((la - b.a + Math.PI) % TAU + TAU) % TAU - Math.PI);
        if (df < b.sp * 1.15 && dd < b.len) lit = Math.max(lit, (1 - df / (b.sp * 1.15)) * b.al);
      }
      return lit;
    }

    function glyph(ctx, ch, x, y, sz, col, lit, rot, ring) {
      ctx.save();
      ctx.translate(x, y);
      if (rot) ctx.rotate(rot);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      if (ring || lit > 0.1) {
        ctx.fillStyle = 'rgba(255,212,92,' + (0.1 + 0.2 * lit + (ring ? 0.1 : 0)).toFixed(3) + ')';
        ctx.beginPath(); ctx.arc(0, 0, sz * (0.8 + 0.4 * lit), 0, TAU); ctx.fill();
      }
      if (ring) { ctx.strokeStyle = 'rgba(255,212,92,0.8)'; ctx.lineWidth = 1; ctx.strokeRect(-sz * 0.6, -sz * 0.6, sz * 1.2, sz * 1.2); }
      ctx.font = Math.round(sz * 1.25) + 'px ' + SERIF;
      ctx.fillStyle = lit > 0.3 ? '#FFF6E2' : ring ? GOLD : 'rgba(170,186,232,0.75)';
      ctx.fillText(ch, 0, sz * 0.1);
      ctx.restore();
    }

    function spout(x, y, n, pow, m, dir, withLetters) {
      for (let k = 0; k < n; k++) {
        const a = -Math.PI / 2 + (dir || 0) + (R() - 0.5) * 1.1, v = m * pow * (0.6 + R() * 0.7);
        const isL = withLetters && R() < 0.45;
        S.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: m * 1.4, age: 0, life: 0.9 + R() * 0.8,
          k: isL ? 'ch' : 'st', ch: ABC[(R() * ABC.length) | 0], c: COLS[(R() * 6) | 0], rot: (R() - 0.5) * 2, vr: (R() - 0.5) * 8, sz: m * (isL ? 0.07 : 0.03) * (0.7 + R() * 0.6) });
      }
    }
    function burst(x, y, n, m, col) {
      for (let k = 0; k < n; k++) {
        const a = R() * TAU, v = m * (0.4 + R() * 0.9);
        S.parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: m * 0.2, age: 0, life: 0.45 + R() * 0.4, k: 'st', c: col || COLS[(R() * 6) | 0], rot: 0, vr: 0, sz: m * 0.022 * (0.6 + R() * 0.8) });
      }
    }
    function pop(x, y, txt, m, col) {
      S.parts.push({ x, y, vx: 0, vy: -m * 0.25, g: 0, age: 0, life: 0.9, k: 'tx', ch: txt, c: col, rot: 0, vr: 0, sz: m * 0.06 });
    }

    function drawParts(ctx, dt) {
      const P = S.parts;
      for (let i = P.length - 1; i >= 0; i--) {
        const p = P[i];
        p.age += dt; p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.rot += p.vr * dt;
        if (p.age > p.life) { P.splice(i, 1); continue; }
        const f = 1 - p.age / p.life, sz = p.sz * (0.4 + 0.6 * Math.min(1, f * 2.2));
        if (p.k === 'ch') glyph(ctx, p.ch, p.x, p.y, sz, p.c, 0, p.rot, false);
        else if (p.k === 'tx') {
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
          ctx.font = '500 ' + Math.round(p.sz) + 'px "DM Mono", monospace';
          ctx.fillStyle = GOLD; ctx.fillText(p.ch, p.x, p.y);
        } else {
          ctx.fillStyle = p.c;
          ctx.beginPath(); sparkle(ctx, p.x, p.y, Math.max(1.2, sz)); ctx.fill();
        }
      }
      if (P.length > 160) P.splice(0, P.length - 160);
    }

    function sky(ctx, w, h, t, spd) {
      const sc = S.scroll, streak = spd * 0.05 * w;
      ctx.fillStyle = BG; ctx.fillRect(0, 0, w, h);
      const g = ctx.createLinearGradient(0, h * 0.45, 0, h);
      g.addColorStop(0, 'rgba(10,14,34,0)'); g.addColorStop(1, 'rgba(14,20,48,0.9)');
      ctx.fillStyle = g; ctx.fillRect(0, h * 0.45, w, h * 0.55);
      ctx.fillStyle = '#8D9AC4';
      ctx.beginPath();
      for (let i = 0; i < stars.length; i++) {
        const s = stars[i];
        let x = (s.x - sc * s.d * 0.3) % 1; if (x < 0) x += 1;
        const X = x * w, Y = s.y * h, tw = 0.55 + 0.45 * Math.sin(t * s.sp + s.ph);
        if (streak * s.d > 2.5) ctx.rect(X, Y, streak * s.d, Math.max(0.6, s.r * 0.6));
        else if (s.r > 1.5) sparkle(ctx, X, Y, s.r * (1.4 + 1.4 * tw));
        else { const z = s.r * (0.6 + 0.8 * tw); ctx.rect(X, Y, z, z); }
      }
      ctx.fill();
    }

    function sea(ctx, w, h, y0, t, lampX) {
      const sc = S.scroll;
      ctx.fillStyle = '#020308'; ctx.fillRect(0, y0, w, h - y0 + 1);
      for (let j = 0; j < 7; j++) {
        const f = j / 6, y = y0 + 2 + (h - y0 - 4) * Math.pow(f, 1.4), sx = 4 + j * 2.6, off = ((sc * w * (0.6 + j * 0.35)) % sx + sx) % sx, sz = 0.7 + j * 0.2;
        ctx.fillStyle = '#26335E'; ctx.globalAlpha = 0.35 + f * 0.4;
        ctx.beginPath();
        for (let x = -off; x < w; x += sx) {
          const yy = y + Math.sin(x * 0.04 + t * 1.6 + j) * (1 + f * 2), dl = Math.abs(x - lampX) / (w * 0.25);
          if (dl < 1 && hash(x * 0.37 + j) > 0.35) continue;
          ctx.rect(x, yy, sz, sz);
        }
        ctx.fill();
        ctx.fillStyle = GOLD; ctx.globalAlpha = 0.9 - f * 0.3;
        ctx.beginPath();
        for (let x = -off; x < w; x += sx) { const dl = Math.abs(x - lampX) / (w * 0.08 + j * 3); if (dl < 1 && hash(x * 0.37 + j) > 0.35) ctx.rect(x, y + Math.sin(x * 0.04 + t * 1.6 + j) * (1 + f * 2), sz * 1.3, sz); }
        ctx.fill();
      }
      ctx.globalAlpha = 1;
    }

    function cloud(ctx, x, y, m, t, flash) {
      const r = m * 0.09;
      const C = [[-1.1, 0.2, 0.75], [-0.4, -0.25, 1], [0.5, -0.1, 0.85], [1.15, 0.25, 0.6], [0.1, 0.35, 0.8]];
      const blobs = (k) => { ctx.beginPath(); for (const c of C) { ctx.moveTo(x + c[0] * r + c[2] * r * k, y + c[1] * r); ctx.arc(x + c[0] * r, y + c[1] * r, c[2] * r * k, 0, TAU); } };
      blobs(1); ctx.fillStyle = '#090C1C'; ctx.fill();
      ctx.fillStyle = '#3A4A80';
      ctx.beginPath();
      for (const c of C) for (let k = 0; k < 14; k++) { const a = k / 14 * TAU; if (Math.sin(a) > 0.2) continue; ctx.rect(x + c[0] * r + Math.cos(a) * c[2] * r - 0.6, y + c[1] * r + Math.sin(a) * c[2] * r - 0.6, 1.2, 1.2); }
      ctx.fill();
      blobs(0.9); ctx.fillStyle = '#090C1C'; ctx.fill();
      const EYE = GOLD, BOLT = '#FFF1D2';
      ctx.fillStyle = EYE;
      for (const sg of [-1, 1]) {
        ctx.beginPath();
        ctx.moveTo(x + sg * r * 0.15, y - r * 0.05);
        ctx.lineTo(x + sg * r * 0.6, y - r * 0.3);
        ctx.lineTo(x + sg * r * 0.55, y + r * 0.08);
        ctx.closePath(); ctx.fill();
      }
      if (flash) {
        ctx.strokeStyle = BOLT; ctx.lineWidth = Math.max(2, m * 0.012); ctx.lineJoin = 'miter';
        ctx.beginPath();
        let bx = x + r * 0.2, by = y + r * 0.6;
        ctx.moveTo(bx, by);
        for (let k = 0; k < 4; k++) { bx += (k % 2 ? 1 : -1) * r * 0.35; by += r * 0.45; ctx.lineTo(bx, by); }
        ctx.stroke();
      }
    }

    // ---------- the loop script ----------
    const LT = 6, TI = [0.9, 1.7, 2.5, 3.5, 4.3], YK = [[0, 0.5], [0.9, 0.36], [1.7, 0.62], [2.5, 0.42], [3.5, 0.66], [4.3, 0.44], [4.95, 0.3], [5.5, 0.48], [6, 0.5]];
    function loopY(lt) {
      for (let i = 1; i < YK.length; i++) if (lt <= YK[i][0]) { const a = YK[i - 1], b = YK[i], k = (lt - a[0]) / (b[0] - a[0]); return lerp(a[1], b[1], 0.5 - 0.5 * Math.cos(k * Math.PI)); }
      return 0.5;
    }

    function spring(key, target, k, d, dt) {
      const p = S.pose, v = S.vel;
      v[key] = (v[key] || 0) + ((target - p[key]) * k - (v[key] || 0) * d) * dt;
      p[key] += v[key] * dt;
    }

    // ---------- composition: the idle key pose of each study ----------
    function comp(w, h, Lb, tall) {
      let L, a, hx, hy;
      // breaching steeply up into the dark, like the footage
      L = Math.min(1.15 * w, 1.0 * h); a = -0.86 - 0.25 * tall; hx = w * 0.8; hy = h * 0.11;
      return { sc: L / Lb, ang: a, x: (hx - 0.45 * L * Math.cos(a)) / w, y: (hy - 0.45 * L * Math.sin(a)) / h };
    }

    return {
      frame(ctx, s) {
        const w = s.w, h = s.h, rm = !!s.rm, mode = rm ? 'idle' : s.mode, mt = rm ? 0 : s.mt;
        const t = rm ? 0 : s.t, dt = rm ? 0 : Math.min(0.05, s.dt || 0);
        S.rm = rm;
        const m = Math.min(w, h), tall = cl((h / w - 0.9) / 1.6, 0, 1);
        const Lb = Math.min(w * (0.62 + 0.62 * tall), h * (1.2 - 0.5 * tall));
        const baseAng = -0.16 - 0.92 * tall;
        const C = comp(w, h, Lb, tall);
        const seaY = h * (0.8 + 0.04 * tall);
        const lhH = Math.min(h * 0.32, w * 0.3);
        let lhX = w * 0.87;
        S.clock += dt;
        const clock = S.clock;
        if (mode !== S.prevMode) {
          if (mode === 'enter') S.d0 = S.scroll;
          if (mode === 'react') S.reactSpout = false;
          if (mode === 'loop') S.prevLt = 0;
          S.prevMode = mode;
        }

        // ----- targets -----
        const T = { x: C.x, y: C.y, ang: C.ang, bend: 0, sc: C.sc, th: TH, eye: 0.35, jaw: 0, fin: 0.6, wave: 0.13, flap: 0 };
        let K = 60, D = 10, spd = 0.035, phs = 2.3, lean = 0, lampBoost = 0, hud = 0, eyeSz = 1, brow = 0;
        let lx = 0.2, ly = -0.2, beamAim = null, beamAlpha = 1, showLetters = true, loopT = -1;
        const hv = s.hover;
        const sway = 0.5 + 0.5 * Math.min(1, 1 / C.sc);

        if (mode === 'idle' || mode === '') {
          T.x += 0.05 * sway * Math.sin(TAU * t / 9);
          T.y += 0.06 * sway * Math.sin(TAU * t / 6.5);
          T.ang = C.ang + 0.14 * Math.cos(TAU * t / 6.5);
          T.fin = 0.55 + 0.3 * Math.sin(t * 1.3);
          const nr = s.near || 0;
          T.eye = 0.32 + 0.75 * nr;
          T.bend = -0.25 * nr;
          lx = 0.35 * nr; ly = 0.2 * nr;
          phs = 2.3 - 1.2 * nr;
          if (mt < 0.4 && !rm) { K = 140; D = 12; }
          if (!rm && clock > S.nextBreath) { S.nextBreath = clock + 7 + R() * 2; S.breath = clock; }
          if (S.breath && clock - S.breath < 1.2) {
            const b = clock - S.breath;
            if (b < 0.45) { T.th = TH * 1.12; T.sc = C.sc * 0.95; T.eye = 0.08; }
            else { T.th = TH * 0.94; T.sc = C.sc * 1.03; T.eye = 0.9; if (!S.breathed) { S.breathed = true; spout(S.blow[0], S.blow[1], 9, 0.9, m, 0, true); } }
          } else S.breathed = false;
          if (S.gag) {
            const g = clock - S.gag.t0;
            if (g < 0.55) { T.th = TH * 1.2; T.sc = C.sc * 0.92; T.eye = 0.02; T.jaw = 0; T.fin = 1.4; T.bend = 0.2; }
            else if (g < 1.0) { T.th = TH * 0.9; T.sc = C.sc * 1.06; T.eye = 1.1; T.bend = -0.3; T.fin = 0.4;
              if (!S.gag.thrown && g > 0.72) {
                S.gag.thrown = true;
                spout(S.blow[0], S.blow[1], 14, 1.2, m, 0.35, false);
                api.emit({ type: 'throw', item: S.gag.item, x: S.blow[0], y: S.blow[1] - m * 0.04, vx: 1, vy: -1.2 });
              }
            } else if (g < 2.2) { T.eye = 0.9; lx = 0.7; ly = -0.6; }
            else S.gag = null;
          }
        } else if (mode === 'react') {
          K = 230; D = 15;
          if (mt < 0.2) { T.th = TH * 1.22; T.sc = C.sc * 0.88; T.bend = -0.45; T.y = C.y + 0.06; T.eye = 1.1; T.fin = 1.5; eyeSz = 1.25; }
          else { T.ang = C.ang - 0.5; T.bend = 0.75; T.y = C.y - 0.07; T.x = C.x; T.fin = 1.75; T.eye = 1.2; T.jaw = 0.55; T.sc = C.sc * 1.06; T.th = TH * 0.95; eyeSz = 1.45;
            if (!S.reactSpout) { S.reactSpout = true; spout(S.blow[0], S.blow[1], 26, 1.25, m, 0.1, true); }
          }
          phs = 5;
          lampBoost = cl((mt - 0.1) * 4, 0, 1);
          beamAim = [S.eyeX, S.eyeY];
          if (hv) { lx = cl((hv.x - S.eyeX) / (w * 0.3), -1, 1); ly = cl((hv.y - S.eyeY) / (h * 0.3), -1, 1); } else { lx = 0.6; ly = 0.2; }
        } else if (mode === 'enter') {
          const e = cl(mt / 0.7, 0, 1);
          K = 120; D = 13;
          T.x = 0.33; T.y = loopY(0); T.ang = -0.05; T.sc = 0.9; T.fin = 0.35; T.eye = 0.85; T.wave = 0.45; T.bend = 0;
          phs = 9;
          spd = e < 0.45 ? lerp(0.05, 3.4, ease(e / 0.45)) : lerp(3.4, 0.42, ease((e - 0.45) / 0.55));
          hud = ease((e - 0.25) / 0.75);
          lx = 0.8; ly = 0;
          beamAlpha = 1 - e * 0.3;
        } else if (mode === 'loop') {
          const lt = mt % LT; loopT = lt;
          K = 200; D = 20; spd = 0.42; hud = 1; phs = 6.5;
          T.x = 0.33; T.y = loopY(lt);
          const dy = (loopY(lt + 0.05) - loopY(lt - 0.05)) / 0.1;
          T.ang = cl(dy * 0.9 * h / w, -0.6, 0.6) - 0.05; T.sc = 0.9; T.fin = 0.6 + 0.3 * Math.sin(lt * 4); T.eye = 0.85; T.wave = 0.22;
          lx = 0.9; ly = 0;
          if (lt > 4.5 && lt < 5.5) { T.bend = 0.5 * Math.sin((lt - 4.5) * Math.PI); T.eye = 1.15; eyeSz = 1.2; }
          if (lt > 2.75 && lt < 3.25) { T.eye = 0.05; T.th = TH * 1.1; }
          showLetters = false;
        } else if (mode === 'squeezed') {
          const q = cl(s.squeeze || 0, 0, 1);
          K = 90; D = 9;
          const sq = Math.min(1, Lb / (C.sc * Lb)) ;
          T.x = lerp(C.x, 0.5, q); T.y = lerp(C.y, 0.5, q); T.sc = lerp(C.sc, Math.min(C.sc, 1), q) * (1 - 0.2 * q); T.bend = 2.7 * q; T.th = TH * (1 + 0.28 * q); T.wave = 0.03; T.fin = 1.9; phs = 0.6;
          T.ang = lerp(C.ang, baseAng, q) - 0.6 * q;
          const glare = mt > 1.3;
          T.eye = glare ? 0.5 : 0.03; brow = glare ? 1 : 0.4 * q; lx = 0.9; ly = -0.2;
          T.x += Math.sin(t * 43) * 0.006 * q * (glare ? 1.6 : 1) * sq;
          lean = -0.2 * q;
          beamAlpha = (Math.sin(t * 31) > -0.2 ? 1 : 0.15);
          if (!rm && q > 0.3 && (!S.popT || clock - S.popT > 0.7)) {
            S.popT = clock;
            const j = JOINTS[(R() * JOINTS.length) | 0], p = at(j.u, j.d);
            S.parts.push({ x: p[0], y: p[1], vx: (R() - 0.5) * m * 1.2, vy: -m * (0.5 + R() * 0.5), g: m * 1.6, age: 0, life: 1.1, k: 'st', c: COLS[(R() * 6) | 0], rot: 0, vr: 0, sz: m * 0.035 });
          }
        }

        if (S.look && clock - S.look.t0 < 1.5 && (mode === 'idle' || mode === 'squeezed')) {
          lx = cl(S.look.dx, -1, 1); ly = cl(S.look.dy, -1, 1); T.eye = Math.max(T.eye, 0.9); T.bend += 0.25 * ly;
        }
        if (S.hit && clock - S.hit.t0 < 0.7) { T.eye = 1.15; eyeSz = Math.max(eyeSz, 1.3); T.th *= 1.1; }

        // ----- integrate pose -----
        if (!S.pose || rm) { S.pose = Object.assign({}, T); S.vel = {}; }
        else for (const k in T) spring(k, T[k], K, D, dt);
        S.ph += dt * phs;
        S.spd = lerp(S.spd, spd, mode === 'enter' ? 1 : Math.min(1, dt * 3));
        S.scroll += S.spd * dt;
        S.scatter = Math.max(0, S.scatter - dt * 1.6);
        const P = S.pose;

        // ----- paint -----
        sky(ctx, w, h, t, S.spd);

        if (!rm && mode === 'idle' && clock > S.nextShoot) { S.nextShoot = clock + 5 + R() * 4; S.shoot = { t0: clock, x: 0.15 + R() * 0.4, y: 0.05 + R() * 0.2 }; }
        if (S.shoot && clock - S.shoot.t0 < 0.7) {
          const k = (clock - S.shoot.t0) / 0.7, x = (S.shoot.x + k * 0.3) * w, y = (S.shoot.y + k * 0.12) * h, ln = m * 0.18 * Math.sin(k * Math.PI);
          ctx.strokeStyle = 'rgba(255,255,255,0.8)'; ctx.lineWidth = 1;
          ctx.lineCap = 'round';
          ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - ln, y - ln * 0.4); ctx.stroke();
        }

        if (mode === 'enter' || mode === 'loop') {
          const dist = S.scroll - S.d0, per = 2.6;
          let fx = lhX / w - dist;
          if (fx < -0.3) fx = ((fx + 0.3) % per + per) % per - 0.3;
          lhX = fx * w;
        }
        const lampPos = [lhX, seaY - lhH * 0.86];

        // the beams
        const Lmax = Math.max(w, h) * 1.25;
        let lampFlash = 0;
        S.beams = [];
        if (beamAim) {
          const a = Math.atan2(beamAim[1] - lampPos[1], beamAim[0] - lampPos[0]);
          const curA = Math.PI + 0.45;
          const k = lampBoost, aa = curA + (((a - curA + Math.PI) % TAU + TAU) % TAU - Math.PI) * k;
          S.beams.push({ x: lampPos[0], y: lampPos[1], a: aa, len: Lmax * (0.6 + 0.4 * k), sp: 0.1, al: 1 });
          lampFlash = k;
        } else {
          const phi = rm ? 0.35 : t * 1.05, c = Math.cos(phi), up = rm ? 0.42 : 0.4 + 0.14 * Math.sin(t * 0.5);
          S.beams.push({ x: lampPos[0], y: lampPos[1], a: Math.PI + up, len: Math.abs(c) * Lmax, sp: 0.15, al: beamAlpha });
          S.beams.push({ x: lampPos[0], y: lampPos[1], a: -0.25, len: Math.abs(c) * Lmax * 0.5, sp: 0.1, al: beamAlpha * 0.7 });
          lampFlash = Math.max(0, 1 - Math.abs(c) / 0.22) * beamAlpha;
        }
        drawBeams(ctx, lampFlash);

        sea(ctx, w, h, seaY, t, lampPos[0]);
        const lp = lighthouse(ctx, lhX, seaY + 2, lhH, t, lean, lampFlash);
        if (lampFlash > 0.02) {
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath(); sparkle(ctx, lp[0], lp[1], lhH * (0.05 + 0.15 * lampFlash)); ctx.fill();
        }

        // whale geometry
        const L = Lb * P.sc;
        build(P.x * w, P.y * h, L, P.ang, P.bend, P.wave, S.ph, P.th, Math.max(0, P.jaw));
        const mouth = at(1, 0.2);

        // idle letters
        let jawPull = 0;
        if (showLetters) {
          const lsz = Math.max(6, m * 0.055);
          for (let i = 0; i < lets.length; i++) {
            const l = lets[i];
            if (!rm) {
              if (l.st === 0) {
                l.x -= dt * (0.035 + S.spd * 0.3);
                const X = l.x * w, Y = l.y * h, dx = mouth[0] - X, dy = mouth[1] - Y, d = Math.hypot(dx, dy);
                if (mode === 'idle' && d < L * 0.24 && (X - mouth[0]) * S.fwd[0] + (Y - mouth[1]) * S.fwd[1] > -L * 0.04) l.st = 1;
                if (l.x < -0.08) Object.assign(l, newLet(1.06 + R() * 0.12));
              } else {
                const X = l.x * w, Y = l.y * h, dx = mouth[0] - X, dy = mouth[1] - Y, d = Math.hypot(dx, dy);
                jawPull = 1;
                const k = Math.min(1, dt * 5.5);
                l.x += (dx * k) / w; l.y += (dy * k) / h; l.sz = Math.max(0.3, l.sz - dt * 1.2);
                if (d < Math.max(4, L * 0.03) || mode !== 'idle') {
                  if (mode === 'idle') { S.pellets.push({ u: 0.93, c: l.c }); burst(mouth[0], mouth[1], 7, m, l.c); }
                  Object.assign(l, newLet(1.06 + R() * 0.12));
                }
              }
            }
            const X = l.x * w, Y = l.y * h + Math.sin(t * 1.4 + l.ph) * m * 0.015;
            if (X < -lsz || X > w + lsz) continue;
            const lit = beamAim ? 0 : litAt(X, Y);
            glyph(ctx, l.ch, X, Y, lsz * l.sz * (1 + 0.25 * lit), l.c, lit, Math.sin(t + l.ph) * 0.2, false);
          }
        }

        // loop: letters to collect, cloud, HUD
        let filled = 0;
        if (loopT >= 0) {
          const lt = loopT, V = 0.42 * w, lsz = Math.max(10, m * 0.085);
          const noseX = P.x * w + Math.cos(-0.05) * L * 0.46, nearest = [];
          for (let i = 0; i < TI.length; i++) {
            const ti = TI[i];
            if (lt >= ti) { filled++; continue; }
            const X = noseX + (ti - lt) * V, Y = (loopY(ti) + Math.sin(-0.05) * 0.46 * L / h) * h;
            nearest.push(ti - lt);
            if (X < w + lsz) glyph(ctx, WORD[i], X, Y + Math.sin(t * 3 + i) * m * 0.01, lsz, COLS[i], 0.6 + 0.4 * Math.sin(t * 6 + i), Math.sin(t * 2 + i) * 0.2, true);
          }
          for (let i = 0; i < TI.length; i++) {
            if (S.prevLt < TI[i] && lt >= TI[i]) {
              S.pellets.push({ u: 0.93, c: COLS[i] });
              burst(S.mouth[0], S.mouth[1], 10, m, COLS[i]);
              pop(S.mouth[0], S.mouth[1] - m * 0.08, '+100', m, COLS[i]);
            }
          }
          if (S.prevLt < 4.62 && lt >= 4.62) { spout(S.blow[0], S.blow[1], 34, 1.7, m, 0, true); pop(cl(S.blow[0], m * 0.4, w - m * 0.4), Math.max(m * 0.32, S.blow[1] - m * 0.1), 'NIGHT! +500', m * 1.2, GOLD); }
          S.prevLt = lt;
          const near = nearest.length ? Math.min.apply(null, nearest) : 9;
          jawPull = cl(1 - (near * V) / (w * 0.22), 0, 1);
          const cx = P.x * w + (3.0 - lt) * V, cy = h * 0.2;
          if (cx > -m * 0.3 && cx < w + m * 0.3) cloud(ctx, cx, cy, m, t, lt > 2.7 && lt < 3.3 && ((t * 14) | 0) % 2 === 0);
        }

        if (!rm && (mode === 'idle' || mode === 'loop')) { S.pose.jaw = lerp(S.pose.jaw, Math.max(T.jaw, jawPull), Math.min(1, dt * 12)); }

        for (let i = S.pellets.length - 1; i >= 0; i--) {
          const p = S.pellets[i];
          p.u -= dt * 0.55;
          if (p.u < 0.02) { const q = [G.px[0], G.py[0]]; burst(q[0], q[1], 6, m * 0.7, p.c); S.pellets.splice(i, 1); }
        }

        if (S.hit && clock - S.hit.t0 < 0.5) {
          const k = (clock - S.hit.t0) / 0.5;
          ctx.strokeStyle = GOLD;
          ctx.globalAlpha = 1 - k; ctx.lineWidth = 1.5;
          ctx.beginPath(); ctx.arc(S.hit.x, S.hit.y, m * 0.04 + k * m * 0.18, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
        }

        // the whale
        const flap = Math.sin(S.ph - 1.2) * (0.25 + P.wave * 1.2);
        drawWhale(ctx, t, { eye: P.eye, fin: P.fin, flap, lx, ly, brow, eyeSz, jaw: P.jaw });
        S.anc = { x: cl(S.eyeX / w, 0.05, 0.95), y: cl(S.eyeY / h, 0.08, 0.95) };

        drawParts(ctx, dt);
        const gp = grain(ctx);
        if (gp) { ctx.save(); ctx.globalAlpha = 0.07; ctx.fillStyle = gp; ctx.translate(((t * 37) | 0) % 128, ((t * 53) | 0) % 128); ctx.fillRect(-128, -128, w + 128, h + 128); ctx.restore(); }

        // HUD (loop)
        if (hud > 0.01) {
          const bs = Math.max(13, m * 0.085), pad = Math.max(8, m * 0.035), y0 = pad - (1 - hud) * (bs + pad * 2);
          const done = loopT > 4.55 && loopT < 5.7;
          const drop = loopT > 5.6 ? (loopT - 5.6) / 0.4 : 0;
          for (let i = 0; i < 5; i++) {
            const x = pad + i * bs * 1.12;
            ctx.fillStyle = 'rgba(5,6,14,0.85)'; ctx.fillRect(x, y0, bs, bs);
            ctx.strokeStyle = done ? GOLD : '#3A4A80'; ctx.lineWidth = done ? 2 : 1;
            ctx.strokeRect(x + 0.5, y0 + 0.5, bs - 1, bs - 1);
            const on = mode === 'loop' && i < filled;
            if (on) {
              ctx.font = Math.round(bs * 0.9) + 'px ' + SERIF;
              ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
              ctx.fillStyle = GOLD;
              ctx.fillText(WORD[i], x + bs / 2, y0 + bs * 0.56 + drop * drop * h * 0.6 + (done ? Math.sin(t * 12 + i) * 2 : 0));
            } else {
              ctx.fillStyle = '#3A4A80';
              ctx.fillRect(x + bs * 0.25, y0 + bs * 0.78, bs * 0.5, 1);
            }
          }
          const lp2 = loopT < 0 ? 0 : loopT;
          const score = 3200 + 1000 * Math.floor((mode === 'loop' ? mt : 0) / LT) + 100 * filled + (lp2 > 4.62 ? 500 : 0);
          const txt = '★ ' + String(score).padStart(5, '0');
          ctx.font = '500 ' + Math.round(bs * 0.62) + 'px "DM Mono", monospace';
          ctx.textAlign = 'right'; ctx.textBaseline = 'middle';
          ctx.fillStyle = GOLD;
          ctx.fillText(txt, w - pad, y0 + bs / 2);
        }
      },
      on(evt) {
        if (!evt || S.rm) return;
        if (evt.type === 'cue') { S.gagN++; S.gag = { t0: S.clock, item: S.gagN % 2 ? 'letter' : 'star', thrown: false }; }
        else if (evt.type === 'hit') {
          S.hit = { x: evt.x || 0, y: evt.y || 0, t0: S.clock };
          S.scatter = 1;
          if (S.vel) { S.vel.ang = (S.vel.ang || 0) + 3.5; S.vel.x = (S.vel.x || 0) + ((S.eyeX > (evt.x || 0)) ? 0.6 : -0.6); }
          burst(evt.x || 0, evt.y || 0, 12, 200, GOLD);
        } else if (evt.type === 'look') { S.look = { dx: evt.dx || 0, dy: evt.dy || 0, t0: S.clock }; }
        else if (evt.type === 'shake') { S.scatter = Math.max(S.scatter, cl(evt.amount || 0.6, 0.2, 1)); if (S.vel) S.vel.y = (S.vel.y || 0) + 0.8 * (evt.amount || 0.6); }
      },
      anchor() { return S.anc; }
    };
  }
};
